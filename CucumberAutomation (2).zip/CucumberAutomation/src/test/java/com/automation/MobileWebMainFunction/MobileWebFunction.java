package com.automation.MobileWebMainFunction;

import com.automation.WebCommonFunction.DriverUtils;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static com.automation.MobileWebMainFunction.BaseClass.driver;

public class MobileWebFunction extends DriverUtils {

    WebElement element=null;

    public void setAcceptAllCookies() throws InterruptedException {
            if(isElementDisplayedID("accept-all-cookies-button")){
                click(driver.findElement(By.id("accept-all-cookies-button")));
            }
    }

    public void clickOnSignOutBtn() throws InterruptedException {
        scrollIntoView(driver.findElement(By.id("signup-btn")));
        click(driver.findElement(By.id("signup-btn")));
    }

    public void clickOnSignUpConfirmBtn() throws InterruptedException {
        element=driver.findElement(By.xpath("(//button[normalize-space()='Sign up'])[2]"));
        scrollIntoView(element);
        Thread.sleep(3000);
        click(element);
        if(isElementDisplayed(element)){
            Thread.sleep(2000);
            click(element);
        }

    }

    public void verifySucesssMsg() throws InterruptedException {
       isElementDisplayed(driver.findElement(By.xpath("//*[contains(normalize-space(),'Thanks')]")));
    }

    public void enterFirstName(String value) throws InterruptedException {
        element=driver.findElement(By.xpath("//input[@aria-label='First Name:']"));
        click(element);
        element.sendKeys(value.replace("random",randomString));
    }
    public void enterLastName(String lastName) throws InterruptedException {
        element=driver.findElement(By.xpath("//input[@aria-label='Last Name:']"));
        click(element);
        element.sendKeys(lastName.replace("random",randomString));
    }
    public void enterEmail(String email) throws InterruptedException {
        element=driver.findElement(By.xpath("//input[@aria-label='Email: ']"));
        click(element);
        element.sendKeys(email.replace("random",randomString));
    }


}
