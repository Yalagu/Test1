package com.automation.MobileWebMainFunction;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class BaseClass {

    public static AppiumDriver driver = null;

    public void launchMobileBrowser(String browserName) throws MalformedURLException {
        UiAutomator2Options capabilities = new UiAutomator2Options()
                .setPlatformName("Android")
                .setDeviceName("emulator-5554").
                setNewCommandTimeout(Duration.ofMinutes(5l))
                .noReset().withBrowserName(browserName);
        capabilities.setCapability("connectHardwareKeyboard", false);

        // Open browser.
        driver =new AppiumDriver(new URL("http://localhost:4723/wd/hub"), capabilities);
        driver.manage()
                .timeouts()
                .implicitlyWait(Duration.ofSeconds(60));
    }
}
