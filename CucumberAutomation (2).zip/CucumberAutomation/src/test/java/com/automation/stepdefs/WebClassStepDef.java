package com.automation.stepdefs;


import com.automation.MobileWebMainFunction.BaseClass;
import com.automation.MobileWebMainFunction.MobileWebFunction;
import com.automation.WebCommonFunction.DriverUtils;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

import java.net.MalformedURLException;

public class WebClassStepDef extends  DriverUtils{
    MobileWebFunction mobileWebFunction=new MobileWebFunction();

    @Given("^I launch mobile '(.*?)' browser in android device$")
    public void launchBrowser(String browserName) throws MalformedURLException {
        new BaseClass().launchMobileBrowser(browserName);
    }

    @When("^I launch url in browser$")
    public void launchURL() {
        BaseClass.driver.get("https://www.premierinn.com/gb/en/home.html");
    }

    @When("^I accept cookies$")
    public void acceptCookies() throws InterruptedException {
        mobileWebFunction.setAcceptAllCookies();
    }

    @And("^I click on sign up btn$")
    public void clickOnSignUpBtnDef() throws InterruptedException {
        mobileWebFunction.clickOnSignOutBtn();

    }

    @And("^I enter first name as '(.*?)'$")
    public void enterFirstName(String fName) throws InterruptedException {
        mobileWebFunction.enterFirstName(fName);
    }

    @And("^I enter last name as '(.*?)'$")
    public void enterLastName(String lName) throws InterruptedException {
        mobileWebFunction.enterLastName(lName);
    }

    @And("^I enter email as '(.*?)'$")
    public void enterEmail(String email) throws InterruptedException {
        mobileWebFunction.enterEmail(email);
    }

    @And("^I click on sign up submit btn$")
    public void clickOnSignUpSubmitBtn() throws InterruptedException {
        mobileWebFunction.clickOnSignUpConfirmBtn();
    }

    @And("^I verify sucess message$")
    public void verifySucessMsg() throws InterruptedException {
        mobileWebFunction.verifySucesssMsg();
    }


}
